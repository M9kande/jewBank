﻿namespace JewBank.Enums;

public enum BlikProfileStatus
{
    Active,
    Disabled
}

public enum BlikCodeStatus
{
    Active,
    Used,
    Expired
}

public enum CustomerStatus
{
    Active,
    Blocked
}

public enum AuditAction
{
    Create,
    Update,
    Delete,
    Read
}

public enum ActorType
{
    Customer,
    Employee,
    System
}

public enum MerchantStatus
{
    Active,
    Suspended
}

public enum AccountType
{
    Checking,
    Savings
}

public enum AccountStatus
{
    Active,
    Frozen,
    Closed
}

public enum BeneficiaryStatus
{
    Active,
    Disabled
}

public enum TransferType
{
    Domestic,
    International,
    Scheduled
}

public enum TransferStatus
{
    Pending,
    Completed,
    Rejected
}

public enum BlikPaymentStatus
{
    Pending,
    Approved,
    Declined
}

public enum TransactionType
{
    Transfer,
    BlikPayment
}

public enum TransactionStatus
{
    Pending,
    Completed,
    Failed
}